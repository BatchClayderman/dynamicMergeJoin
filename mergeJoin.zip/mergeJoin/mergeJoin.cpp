﻿#include <iostream>
#if defined WIN32 || defined _WIN32 || defined _WIN64
#include <windows.h>
#ifndef TIME_POINT_TYPE
#define TIME_POINT_TYPE chrono::steady_clock::time_point
#endif
#else
#include <algorithm>
#ifndef TIME_POINT_TYPE
#define TIME_POINT_TYPE chrono::system_clock::time_point
#endif
#endif
#include <fstream>
#include <string>
#include <sstream>
#include <map>
#include <chrono>
#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#endif
#ifndef EXIT_FAILURE
#define EXIT_FAILURE 1
#endif
#ifndef EOF
#define EOF (-1)
#endif
#ifndef USE_VECTOR
#define USE_VECTOR 1
#endif
#ifndef INF_STRING
#define INF_STRING "z"
#endif
#ifdef USE_VECTOR
#include <vector>
#else
#include <set>
#endif
using namespace std;


class MergeJoin
{
private:
	string basicsFilePath, akasFilePath, outputFilePath;
	ifstream basicsFilePointer, akasFilePointer;
	ofstream outputFilePointer;
	bool flag = false;

	bool close(ifstream& filePointer, const string filePath)
	{
		try
		{
			if (filePointer.is_open())
				filePointer.close();
			if (!filePath.empty())
				cout << "Successfully close the input file \"" << filePath << "\". " << endl;
			return true;
		}
		catch (...)
		{
			if (!filePath.empty())
				cout << "Failed to close the input file \"" << filePath << "\". " << endl;
			return false;
		}
	}
	bool close(ifstream& filePointer) { return this->close(filePointer, ""); }
	bool close(ofstream& filePointer, const string filePath)
	{
		try
		{
			if (filePointer.is_open())
				filePointer.close();
			if (!filePath.empty())
				cout << "Successfully close the output file \"" << filePath << "\". " << endl;
			return true;
		}
		catch (...)
		{
			if (!filePath.empty())
				cout << "Failed to close the output file \"" << filePath << "\". " << endl;
			return false;
		}
	}
	bool close(ofstream& filePointer) { return this->close(filePointer, ""); }
	bool closeAll()
	{
		bool bRet = true;
		bRet = this->close(this->basicsFilePointer);
		bRet = this->close(this->akasFilePointer) && bRet;
		bRet = this->close(this->outputFilePointer) && bRet;
		this->flag = false;
		cout << (bRet ? "All the file pointers are closed. " : "Failed to close one or more file pointers. ") << endl;
		return bRet;
	}
	void readBasicsFile(string& m0, string& m1)
	{
		try
		{
			string line{};
			getline(this->basicsFilePointer, line);
			if (this->basicsFilePointer.eof()) //  judge after getline
			{
				m0 = INF_STRING;
				m1 = INF_STRING;
				cout << "Finish reading \"" << this->basicsFilePath << "\". " << endl;
				this->flag = false;
			}
			else
			{
				stringstream ss(line);
				getline(ss, m0, '\t');
				getline(ss, line, '\t'); // skip the token
				getline(ss, m1, '\t');
			}
		}
		catch (...)
		{
			cout << "Failed to read a line from \"" << this->basicsFilePath << "\". The file will be closed soon. " << endl;
			this->close(this->basicsFilePointer, this->basicsFilePath);
			this->flag = false;
		}
		return;
	}
	void readAkasFile(string& n0, string& n1, string& n2)
	{
		try
		{
			string line{};
			getline(this->akasFilePointer, line);
			if (this->akasFilePointer.eof()) //  judge after getline
			{
				n0 = INF_STRING;
				n1 = INF_STRING;
				n2 = INF_STRING;
				cout << "Finish reading \"" << this->akasFilePath << "\". " << endl;
				this->flag = false;
			}
			else
			{
				stringstream ss(line);
				getline(ss, n0, '\t');
				getline(ss, line, '\t'); // skip the token
				getline(ss, n1, '\t');
				getline(ss, n2, '\t');
			}
		}
		catch (...)
		{
			cout << "Failed to read a line from \"" << this->akasFilePath << "\". The file will be closed soon. " << endl;
			this->close(this->akasFilePointer, this->akasFilePath);
			this->flag = false;
		}
		return;
	}
#ifdef USE_VECTOR
	unsigned int write(string identifier, string primaryTitle, map<string, vector<string>> d)
#else
	unsigned int write(string identifier, string primaryTitle, map<string, set<string>> d)
#endif
	{
		stringstream ss{};
		ss << identifier << "\t" << primaryTitle;
#ifdef USE_VECTOR
		for (map<string, vector<string>>::iterator mapIt = d.begin(); mapIt != d.end(); ++mapIt)
		{
			ss << "\t" << mapIt->first << " (";
			ss << mapIt->second[0];
			for (size_t i = 1; i < mapIt->second.size(); ++i)
				ss << "," << mapIt->second[i];
			ss << ")";
		}
#else
		for (map<string, set<string>>::iterator mapIt = d.begin(); mapIt != d.end(); ++mapIt)
		{
			ss << "\t" << mapIt->first << " (";
			set<string>::iterator setIt = mapIt->second.begin();
			ss << *setIt;
			for (++setIt; setIt != mapIt->second.end(); ++setIt)
				ss << "," << *setIt;
			ss << ")";
		}
#endif
		ss << "\n";
		try
		{
			this->outputFilePointer << ss.str();
			return 1;
		}
		catch (...)
		{
			cout << "Failed to write the following line to \"" << this->outputFilePath << "\". " << endl << ss.str();
			return 0;
		}
	}
	
public:
	MergeJoin(const string basicsFilePath, const string akasFilePath, const string outputFilePath)
	{
		this->basicsFilePath = basicsFilePath;
		this->akasFilePath = akasFilePath;
		this->outputFilePath = outputFilePath;
	}
	bool initialize()
	{
		try
		{
			this->basicsFilePointer.open(basicsFilePath, ios::binary);
			this->akasFilePointer.open(akasFilePath, ios::binary);
			this->outputFilePointer.open(outputFilePath, ios::binary);
			if (this->basicsFilePointer.is_open() && this->akasFilePointer.is_open() && this->outputFilePointer.is_open())
			{
				string line{};
				if (!this->basicsFilePointer.eof())
					getline(this->basicsFilePointer, line);
				if (!this->akasFilePointer.eof())
					getline(this->akasFilePointer, line);
				this->outputFilePointer.write("titleId\tprimaryTitle\ttitle (regions)\n", 37);
				if (this->basicsFilePointer.eof() || this->akasFilePointer.eof()) // one of them reports EOF
				{
					cout << "Failed to initialize since one or more input files have no real data. " << endl;
					this->closeAll();
					this->flag = false;
				}
				else
					this->flag = true;
			}
			else
			{
				cout << "Failed to initialize since one or more file pointers are not opened successfully. " << endl;
				this->closeAll();
				this->flag = false;
			}
		}
		catch (...)
		{
			cout << "Failed to initialize since unexpected exceptions occurred. " << endl;
			this->closeAll();
			this->flag = false;
		}
		return this->flag;
	}
	unsigned int join()
	{
		/* Status Checking */
		if (!this->flag)
		{
			cout << "Please call ``initialize`` before calling ``join``. " << endl;
			return 0;
		}
		
		/* Preparation */
		unsigned int cnt = 0;
		string m0{}, m1{}, n0{}, n1{}, n2{};
		
		/* Main Algorithm */
		cout << "Start to perform the \"merge join\" operation. " << endl;
		TIME_POINT_TYPE startTime = chrono::high_resolution_clock::now();
		this->readBasicsFile(m0, m1);
		this->readAkasFile(n0, n1, n2);
		while (this->flag)
		{
			if (m0 == n0)
			{
#ifdef USE_VECTOR
				map<string, vector<string>> titles{};
#else
				map<string, set<string>> titles{};
#endif
				while (n0 == m0)
				{
					if (titles.find(n1) == titles.end())
					{
#ifdef USE_VECTOR
						vector<string> s{ n2 };
#else
						set<string> s{ n2 };
#endif
						titles[n1] = s;
					}
#ifdef USE_VECTOR
					else if (find(titles[n1].begin(), titles[n1].end(), n2) == titles[n1].end())
						titles[n1].push_back(n2);
#else
					else
						titles[n1].insert(n2);
#endif
					this->readAkasFile(n0, n1, n2);
				}
				
				cnt += this->write(m0, m1, titles);
#if defined DEBUG || defined _DEBUG
				if (cnt % 10000 == 0)
#else
				if (cnt % 1000000 == 0)
#endif
				{
					double timeDelta = (chrono::high_resolution_clock::now() - startTime).count() / 1000000000.0;
					cout << "Successfully write " << cnt << " datum lines to \"" << this->outputFilePath << "\" in " << timeDelta << " second(s) at " << cnt / timeDelta << " datum/s. " << endl;
				}
				this->readBasicsFile(m0, m1);
			}
			else if (m0 > n0)
				this->readAkasFile(n0, n1, n2);
			else
				this->readBasicsFile(m0, m1);
		}
		this->closeAll();
		double timeDelta = (chrono::high_resolution_clock::now() - startTime).count() / 1000000000.0;
		cout << "Finish performing the \"merge join\" operation with " << cnt << " datum lines written in " << timeDelta << " second(s) at " << cnt / timeDelta << " datum/s. " << endl;
		this->flag = false;
		return cnt;
	}
};


#if defined WIN32 || defined _WIN32 || defined _WIN64
static void cdCurrentDirectory()
{
	char path[MAX_PATH + 1] = { NULL };
	GetModuleFileNameA(NULL, path, MAX_PATH);
	string::size_type pos = string(path).find_last_of("\\/");
	string dir = string(path).substr(0, pos);
	SetCurrentDirectoryA(dir.c_str());
	GetCurrentDirectoryA(MAX_PATH, path);
	cout << "The working directory has been changed to \"" << path << "\". " << endl;
	return;
}
#endif

static void pressAnyKeyToContinue()
{
	rewind(stdin);
	fflush(stdin);
	cout << "The program is about to exit. Please press any key to continue. " << endl;
#if defined WIN32 || defined _WIN32 || defined _WIN64
	UNREFERENCED_PARAMETER(getchar()); // avoid C4189
#else
	getchar();
#endif
	return;
}



int main()
{
#if defined WIN32 || defined _WIN32 || defined _WIN64
	cdCurrentDirectory();
#endif
	MergeJoin mergeJoin("../../../title.basics.tsv", "../../../title.akas.tsv", "../../../output.mergeJoinCpp.tsv");
	int iRet = mergeJoin.initialize() ? (mergeJoin.join() ? EXIT_SUCCESS : EXIT_FAILURE) : EOF;
	pressAnyKeyToContinue();
	return iRet;
}